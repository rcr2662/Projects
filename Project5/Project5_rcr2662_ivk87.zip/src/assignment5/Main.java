/* CRITTERS GUI <Main.java>
 * EE422C Project 5 submission by
 * Replace <...> with your actual data.
* Roberto Reyes
 * rcr2662
 * 17360
 * Ishan Kumar
 * ivk87
 * <Student2 5-digit Unique No.>
 * Slip days used: <0>
 * Spring 2022
 */
package assignment5;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import assignment5.Critter.TestCritter;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;


public class Main extends Application {
	
	public static void main(String[] args) {
        launch(args);
    }
    //Start
	@Override
	public void start(Stage primaryStage) { //WORKS BUT ADJUST SIZE
	
		primaryStage.setTitle("Critter World");
        //BorderPane setup
		ArrayList<Button> history = new ArrayList<Button>(); //adds buttons on top
		ArrayList<Button> Critter_buttons = new ArrayList<Button>(); //data structure handsing critter buttons
		BorderPane border = new BorderPane();
		HBox hbox = addHBox(history);
		border.setTop(hbox);
		addStackPane(hbox);         // Add stackpane to HBox in top region
		border.setCenter(addGridPane());    //gridpane in the center
		border.setRight(addFlowPane(Critter_buttons));    //flowpane on the right
	
	
		
		try {
			Scene scene = new Scene(border,1500,700);
			ImplementButton runner = new ImplementButton(scene,border,Critter_buttons);	
			
			for(int x = 0; x < history.size(); x++)
			{
					Method call = runner.getClass().getDeclaredMethod(history.get(x).getText(),Button.class);
					call.invoke(runner, history.get(x));
			}
				primaryStage.setScene(scene);
				primaryStage.show();	
	
		} catch(Exception e) {
			//e.printStackTrace();
		}
		
	
    }

	

	//Initialize HBox with buttons for each command
	public HBox addHBox(ArrayList<Button> history) { //WORKS
		HBox hbox = new HBox();
	
	    hbox.setPadding(new Insets(30, 24, 15, 12));
	    hbox.setSpacing(10);
	    hbox.setStyle("-fx-background-color: #336699;");
	    
	   Button buttonSeed = new Button("Seed");
	    buttonSeed.setPrefSize(100, 20);
	    //ImplementButton.seed(buttonSeed);
	    history.add(buttonSeed);
	    
	    Button buttonCreate = new Button("Create");
	    buttonCreate.setPrefSize(100, 20);
	    //ImplementButton.create(buttonCreate);
	    history.add(buttonCreate);
	    
	    Button buttonCreatenum = new Button("Createnum");
	    buttonCreatenum.setPrefSize(100, 20);
	    //ImplementButton.create(buttonCreate);
	    history.add(buttonCreatenum);
	    TextField Creationtext = new TextField();
	    Creationtext.setPrefWidth(80);
	    
	    Button buttonShow = new Button("Show");
	    buttonShow.setPrefSize(100, 20);
	    //ImplementButton.show(buttonShow);
	    history.add(buttonShow);
	    
	    Button buttonStep = new Button("Step");
	    buttonStep.setPrefSize(100, 20);
	    //ImplementButton.step(buttonStep);
	    history.add(buttonStep);

	    
	    Button buttonStepnum = new Button("Stepnum");
	    buttonStepnum.setPrefSize(100, 20);
	    //ImplementButton.buttonStepnum(buttonStepnum);
	    history.add(buttonStepnum);
	    TextField Stepnumtext = new TextField();
	    Stepnumtext.setPrefWidth(80);
	    ImplementButton.initTexts(Stepnumtext,Creationtext);
	    
	    Button buttonAnimation = new Button("Start_Animation");
	    buttonAnimation.setPrefSize(100, 20);
	   // ImplementButton.startanimation(buttonAnimation);
	    history.add(buttonAnimation);
	    
	    Button buttonAnimationStop = new Button("Stop_Animation");
	    buttonAnimationStop.setPrefSize(100, 20);
	    history.add(buttonAnimationStop);
	    
	    Button buttonStats = new Button("Stats");
	    buttonStats.setPrefSize(100, 20);
	   // ImplementButton.stats(buttonStats);
	    history.add(buttonStats);
	    
	    Button buttonClear = new Button("Clear");
	    buttonClear.setPrefSize(100, 20);
	    //ImplementButton.clear(buttonClear);
	  
	    history.add(buttonClear);
	    
	    Button buttonQuit = new Button("Quit");
	    buttonQuit.setPrefSize(100, 20);
	  
	   history.add(buttonQuit);
	    
	   
	    //ImplementButton.setButtons(history);
	    
	    hbox.getChildren().addAll(buttonSeed, buttonCreate,buttonCreatenum,Creationtext,buttonShow, buttonStep, buttonStepnum,Stepnumtext,buttonAnimation,
	    		buttonAnimationStop, buttonStats, buttonClear, buttonQuit);

	    return hbox;
	}
	

	//Creates help button in top right
	public void addStackPane(HBox hb) { //WORKS
	    StackPane stack = new StackPane();
	    Rectangle helpIcon = new Rectangle(30.0, 25.0);
	    helpIcon.setFill(new LinearGradient(0,0,0,1, true, CycleMethod.NO_CYCLE,
	        new Stop[]{
	        new Stop(0,Color.web("#4977A3")),
	        new Stop(0.5, Color.web("#B0C6DA")),
	        new Stop(1,Color.web("#9CB6CF")),}));
	    helpIcon.setStroke(Color.web("#D0E6FA"));
	    helpIcon.setArcHeight(3.5);
	    helpIcon.setArcWidth(3.5);

	    Text helpText = new Text("?");
	    helpText.setFont(Font.font("Verdana", FontWeight.BOLD, 18));
	    helpText.setFill(Color.WHITE);
	    helpText.setStroke(Color.web("#7080A0")); 

	    stack.getChildren().addAll(helpIcon, helpText);
	    stack.setAlignment(Pos.CENTER_RIGHT);     // Right-justify nodes in stack
	    StackPane.setMargin(helpText, new Insets(0, 10, 0, 0)); // Center "?"

	    hb.getChildren().add(stack);            // Add to HBox from Example 1-2
	    HBox.setHgrow(stack, Priority.ALWAYS);    // Give stack any extra space
	}
	
	public GridPane addGridPane() {
	    GridPane grid = new GridPane();
	    grid.setHgap(10);
	    grid.setVgap(10);
	    grid.setPadding(new Insets(0, 10, 0, 10));

	   //add elements to the grid

	    return grid;
	}
	
    //Creates flowpane of buttons on right used for each critter
	public FlowPane addFlowPane( ArrayList<Button> Critter_buttons ) { //Works
	    FlowPane flow = new FlowPane();
	    flow.setPadding(new Insets(5, 0, 5, 0));
	    flow.setVgap(4);
	    flow.setHgap(4);
	    flow.setPrefWrapLength(170); // preferred width allows for two columns
	    flow.setStyle("-fx-background-color: DAE6F3;");
	    // search trhough classes in package
	    File f = new File("Project_5/src/assignment5");
		 String[] files = f.list();
		 
	      String myPackage = Critter.class.getPackage().toString().split(" ")[1];

	    for (int i = 0; i < files.length; i++) {
	    	  
            // add nodes to the flow pane
	    	
	    	 String class_name = files[i];
	    	if(files[i].indexOf(".java") != -1)
	    	    {class_name = files[i].substring(0,files[i].indexOf(".java"));}
	    	final String final_class_name = class_name;
	    	try {
				Class claz = Class.forName(myPackage+"."+final_class_name);
				if((Critter.class.isAssignableFrom(claz) || TestCritter.class.isAssignableFrom(claz) )  && !claz.equals(Critter.class))
				{
					Button critters = new Button(class_name);
					Critter_buttons.add(critters); //registers all critters
					flow.getChildren().add(critters);
				}
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			}
	    }

	    return flow;
	}
		
}
