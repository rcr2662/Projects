/* CRITTERS GUI <ImplementButton.java>
 * EE422C Project 5 submission by
 * Replace <...> with your actual data.
* Roberto Reyes
 * rcr2662
 * 17360
 * Ishan Kumar
 * ivk87
 * <Student2 5-digit Unique No.>
 * Slip days used: <0>
 * Spring 2022
 */
package assignment5;


import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import assignment5.Critter;
import javafx.animation.AnimationTimer;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

    class ImplementButton {
    	
    
    	 private Scene scene;
    	 private BorderPane border;
    	 /*Math Variables*/
    	 private boolean StopAnime = false;
    	 private int StepsPerFrame = 1; 
    	 private int CreatePerFrame = 1;
    	 private String Name_Of_Critter;
    	  private ArrayList<Button> Critter_buttons;
    	  private Button[] Clicked_Button = new Button[1];
    	 /*STATIC VARIABLES*/
    	
    	private static TextField TextFieldStep;
    	private static TextField TextFieldCreate;
 
    	ImplementButton(Scene scene,BorderPane border,ArrayList<Button> Critter_buttons)
    	{
    		this.scene = scene;
    		this.border = border;
    		StopAnime = false;
    		StepsPerFrame = 1;
    		CreatePerFrame = 1;
    		this.Critter_buttons =  Critter_buttons;
    		InitButtons();
    	}

		private void setScene(BorderPane border)
		{ this.scene.setRoot(border);}
		private void setStepsPerFrame(int val)
		{StepsPerFrame = val;}
		private void setCreatePerFrame(int val)
		{CreatePerFrame = val;}
		private void setStopAnime(boolean val)
		{StopAnime = val;}
		
		private void Reset()
		{StopAnime = false;
		StepsPerFrame = 1;
		CreatePerFrame = 1;
		TextFieldStep.clear();
		TextFieldCreate.clear();
		}
		private void InitButtons()
		{
			  for (Button critters: Critter_buttons) {
				 
			       critters.setOnAction(new EventHandler<ActionEvent>()
			    		   {
			    	   			@Override
			    		   public void handle(ActionEvent event)
			    		   {if(!StopAnime){setCreatorName(critters);} }

			    		   }
			       
			    		   );
				  
			    }
			
		}
		private void setCreatorName(Button critters)
		{Name_Of_Critter = critters.getText(); SetClickedButton(critters);}
		private void SetClickedButton(Button critters)
		{
			if(Clicked_Button[0] == null) {Clicked_Button[0] = critters; Clicked_Button[0].setStyle("-fx-background-color: green");}
			 else {Clicked_Button[0].setStyle("-fx-background-color: red");}
			 Clicked_Button[0] = critters;Clicked_Button[0].setStyle("-fx-background-color: green");
		}
		 private String getCreatorName()
		{return Name_Of_Critter;} 
		 
		static void initTexts(TextField one, TextField two)
		{TextFieldStep = one;TextFieldCreate = two;}
		
    	  public void Quit(Button btn) //WORKS
    	 {
    		 btn.setOnAction(new EventHandler<ActionEvent>() {
    			    @Override
    			    public void handle(ActionEvent event) {
    			        System.exit(0);
    			    }
    			});
    	 }
    	  public void Clear(Button btn) //WORKS
     	 {
    		 
     		 btn.setOnAction(new EventHandler<ActionEvent>() {
     			    @Override
     			    public void handle(ActionEvent event) {
     			    	if(!StopAnime) {
     			       Critter.clearWorld();
     			       Reset();
     			    	}
     			    }
     			});
    		 
     	 }
    	  public void Show(Button btn) //Works but Fix SIZING
    	  {
    	
    		  btn.setOnAction(new EventHandler<ActionEvent>() {
   			    @Override
   			    public void handle(ActionEvent event) {
   			    	if(!StopAnime) {
   			    		Show();
   			    	}
   			    }
   			});  
    		  
    	  }
    	  public void Step(Button btn) { //WORKS
    	
    		  btn.setOnAction(new EventHandler<ActionEvent>() {
     			    @Override
     			    public void handle(ActionEvent event) {
     			    	if(!StopAnime) {
     			    		Step();
     			    }
     			    }
     			}); 
    		  
    		  
    	  }
    	  public void Seed(Button btn) { //works
    		  btn.setOnAction(new EventHandler<ActionEvent>() {
      			 
    			  @Override
     			    public void handle(ActionEvent event) {
    				  if(!StopAnime) {
    					  Critter.setSeed(100);
    			  }
    			  }
     			});  
    		  
    		  
    	  }
    	  public void Create(Button btn) { //WORKS
    		
    		  btn.setOnAction(new EventHandler<ActionEvent>() {
     			 
    			  @Override
     			    public void handle(ActionEvent event) {
    				  if(!StopAnime) {
    		  for(int x = 0; x < CreatePerFrame; x++) 
    			  {
					try {
						
						Critter.createCritter(Name_Of_Critter);
					} catch (InvalidCritterException e) {
						// TODO Auto-generated catch block
						//e.printStackTrace();
					}
    			  	}
    				  }
    			  }
     			});  
    		 
    	  }
 
    	  
    	  public void Createnum(Button btn) { //Works
      		
    		  btn.setOnAction(new EventHandler<ActionEvent>() {
     			 
    			  @Override
     			    public void handle(ActionEvent event) {
    					if(!StopAnime) {
       			    		String hi = "1";
       			    		if(TextFieldCreate.getText() == null ||TextFieldCreate.getText().trim().isEmpty()) {}
       			    		else{hi = TextFieldCreate.getText();}
       			    		int val = Integer.valueOf(hi);
       			    		setCreatePerFrame(val);
       			    		
       			    	}
    			  }
    		  }); 
    	  }
    	  
    	  public void Stepnum(Button btn) { //Works
    	
    		  btn.setOnAction(new EventHandler<ActionEvent>() {
   			    @Override
   			    public void handle(ActionEvent event) {
   			    	if(!StopAnime) {
   			    	
   			    		String hi = "1";
   			    		if(TextFieldStep.getText() == null ||TextFieldStep.getText().trim().isEmpty() ) {}
   			    		else{hi = TextFieldStep.getText();}
   			    		int val = Integer.valueOf(hi); 
   			    		setStepsPerFrame(val);
   			    		
   			    	}
   			    }});  
    		  
    	  }
    	  public void Start_Animation(Button btn) { //Works
    		  
    		  btn.setOnAction(new EventHandler<ActionEvent>() {
   			    @Override
   			    public void handle(ActionEvent event) {
   			    	setStopAnime(true); //Disable All Buttons
   			    	new AnimationTimer(){
   			    		private long new_time = 0; 
   			    		@Override
   			    		public void handle(long time)
   			    		{
   			    			if(time - new_time >= 500_000_000) //500 ms timer
   			    			{Step(); Show();Stats();new_time = time;}
   			    			if(!StopAnime)
   	   			    		{this.stop();}
   			    		}
   			    	
   			    	}.start();
   			    }
   			}); 
    		  
    	  }
    	  public void Stop_Animation(Button btn) { //Works
    		  
    		  btn.setOnAction(new EventHandler<ActionEvent>() {
     			    @Override
     			    public void handle(ActionEvent event) {
     			    	setStopAnime(false);
     			    }
     			}); 
    		  
    	  }
    	
    	  
    	  public void Stats(Button btn) { //works
    		  btn.setOnAction(new EventHandler<ActionEvent>() {
     			    @Override
     			    public void handle(ActionEvent event) {
     			   	if(!StopAnime) {Stats();}
     			    }
     			}); 
    	  }
    	  
    	  private void Step()
    	  {
    		  for(int x = 0; x < StepsPerFrame;x++)
    			  {Critter.worldTimeStep();}
		    } 
    	  
    	  private void Show()
    {
    	 GridPane world = new GridPane();
			   world.setAlignment(Pos.CENTER);
			world.setGridLinesVisible(true);
			       Critter.displayWorld(world);
			       border.setCenter(world);
			       setScene(border);
    }
    	  private void Stats()
    	  {
    		
		    		
				List<Critter> Dummy = new ArrayList<Critter>();
				try {
					Dummy = Critter.getInstances(Name_Of_Critter);
				} catch (InvalidCritterException e1) {
					// TODO Auto-generated catch block
					//e1.printStackTrace();
				}
						
					Class claz = Critter.class;
					try {
						claz = Class.forName("assignment5"+"." + Name_Of_Critter); //this guerenteed
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						//e1.printStackTrace();
					}
				
				try {
					Method E = claz.getDeclaredMethod("runStats",List.class); //OVERRIDED RUNSTATS
					String stats = (String) E.invoke(null, Dummy);
					PrintStats(stats);
				} catch ( NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
					
					try {
						Method E = claz.getSuperclass().getDeclaredMethod("runStats",List.class); //CRITTER
						String stats = (String) E.invoke(null, Dummy);
						PrintStats(stats);
					} catch (NoSuchMethodException | SecurityException | IllegalAccessException | InvocationTargetException e1) {

						try {
							Method E = claz.getSuperclass().getSuperclass().getDeclaredMethod("runStats",List.class); //TEST CRITTER
							String stats = (String) E.invoke(null, Dummy);
							PrintStats(stats);
						} catch (NoSuchMethodException | SecurityException | IllegalAccessException | InvocationTargetException e2) {
							// TODO Auto-generated catch block
							//e2.printStackTrace();
						}
					}

				}

	    		
		    		}
    	  
    	  private void PrintStats(String stats)
    	  {	  
    	Label myLabel = new Label();
    	myLabel.setText("STATS:\n" + stats);
    	border.setLeft(myLabel);
    	setScene(border);		     
    	  }
    	  
    	  
}
