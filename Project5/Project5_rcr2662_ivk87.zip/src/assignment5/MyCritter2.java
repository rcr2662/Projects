/*
 * Do not change or submit this file.
 */

package assignment5;

import assignment5.Critter.TestCritter;

public class MyCritter2 extends TestCritter {

    public String toString() {
        return "2";
    }

    public boolean fight(String opponent) {
        // same species as me!
        if (toString().equals(opponent)) {
            /* try to move away */
        	
            walk(Critter.getRandomInt(8));
        }
        return false;
    }

    public void doTimeStep() {
    	boolean steps = false;
    	switch(Critter.getRandomInt(2)) {
    		case 0:
    			steps = false;
    			break;
    		case 1:
    			steps = true;
    			break;
    			 
    	}
    	look(Critter.getRandomInt(8),steps);
        setEnergy(getEnergy() + Params.PHOTOSYNTHESIS_ENERGY_AMOUNT);
    }

    public CritterShape viewShape() {
        return CritterShape.CIRCLE;
    }

    public javafx.scene.paint.Color viewColor() {
        return javafx.scene.paint.Color.GREEN;
    }
}
