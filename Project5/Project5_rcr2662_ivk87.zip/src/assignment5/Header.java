/* CRITTERS GUI <MyClass.java>
 * EE422C Project 5 submission by
 * Replace <...> with your actual data.
* Roberto Reyes
 * rcr2662
 * 17360
 * Ishan Kumar
 * ivk87
 * <Student2 5-digit Unique No.>
 * Slip days used: <0>
 * Spring 2022
 */

/*
   Describe here known bugs or issues in this file. If your issue spans multiple
   files, or you are not sure about details, add comments to the README.txt file.
 */
package assignment5;

// 1. When the world params are too small, the full world doesn't fit in the window
// 2. Struggled creating a star
// 3. May throw null pointer exception in addFlowPane()
