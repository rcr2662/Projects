/*
 * CRITTERS Critter.java
 * EE422C Project 4 submission by
 * Replace <...> with your actual data.
 * Roberto Reyes
 * rcr2662  
 * 17360
 * Ishan Kumar
 * ivk87
 * <Student2 5-digit Unique No.>
 * Slip days used: <0>
 * Fall 2021
 */
package assignment5;

import javafx.geometry.Point2D;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.text.Text;
 /* START --- NEW FOR PROJECT 5 */
public abstract class Critter {
    public enum CritterShape {
        CIRCLE,
        SQUARE,
        TRIANGLE,
        DIAMOND,
        STAR
    }

    /* the default color is white, which I hope makes critters invisible by default
     * If you change the background color of your View component, then update the default
     * color to be the same as you background
     *
     * critters must override at least one of the following three methods, it is not
     * proper for critters to remain invisible in the view
     *
     * If a critter only overrides the outline color, then it will look like a non-filled
     * shape, at least, that's the intent. You can edit these default methods however you
     * need to, but please preserve that intent as you implement them.
     */
    public javafx.scene.paint.Color viewColor() {
        return javafx.scene.paint.Color.WHITE;
    }

    public javafx.scene.paint.Color viewOutlineColor() {
        return viewColor();
    }

    public javafx.scene.paint.Color viewFillColor() {
        return viewColor();
    }

    public abstract CritterShape viewShape();

    protected final String look(int direction, boolean steps) {
    	Params param = new Params();
    	String RESET_COORD = getCoords(this);
    	String OG_Cord = "";
    	if(!Orig_Coord[0].equals("-1") && !LookIs_Called_In_Fight) { OG_Cord = Orig_Coord[0];setCoords(this,OG_Cord);} //bases it off of Orig Position
		if (steps)
			{run(direction); 
			energy+= param.RUN_ENERGY_COST;}
		else
			{walk(direction);
			energy +=param.WALK_ENERGY_COST;}
		
    	String Look_coord = getCoords(this);
    	setCoords(this,RESET_COORD); //resets Coord
    	energy-=param.LOOK_ENERGY_COST; //subtracts look cost
    	
    	 if(OldMap.get(Look_coord) == null) //O(1)
    		 {return null;}
    	 
    	return OldMap.get(Look_coord).toString();
    }

    public static String runStats(List<Critter> critters) {
        // TODO Implement this method
    	String ret = "";
    	ret +="" + critters.size() + " critters as follows -- ";
    	 //System.out.print("" + critters.size() + " critters as follows -- ");
         Map<String, Integer> critter_count = new HashMap<String, Integer>();
         for (Critter crit : critters) {
             String crit_string = crit.toString();
             critter_count.put(crit_string,
                     critter_count.getOrDefault(crit_string, 0) + 1);
         }
         String prefix = "";
         for (String s : critter_count.keySet()) {
        	 
            // System.out.print(prefix + s + ":" + critter_count.get(s));
        	 ret+= " "+ prefix + s + ":" + critter_count.get(s);
             prefix = ", ";
         }
         ret+="\n";
         //System.out.println();
       return ret;
    }
private static Shape createShape(int x,int y) //ADJUST SIZE
{
	int min = Math.min(1400/Params.WORLD_WIDTH, 600/Params.WORLD_WIDTH);
	Shape s = new Circle(0,0,0,Color.WHITE);
	switch(OldMap.get(x+ SPACE + y).viewShape()) {
	case CIRCLE:
		 s = new Circle(min,OldMap.get(x+ SPACE + y).viewOutlineColor());
		 break;
	case SQUARE:
		 s = new Rectangle(min,min,OldMap.get(x+ SPACE + y).viewOutlineColor());
		 break;
	case TRIANGLE:
		double height = Math.sqrt(min*min - min*min/4);
		Point2D p1 = new Point2D(x, y-height/2);
		Point2D p2 = new Point2D(x-min/2, y+height/2);
		Point2D p3 = new Point2D(x+min/2, y+height/2);
		s = new Polygon(p1.getX(), p1.getY(), p2.getX(), p2.getY(), p3.getX(), p3.getY());
		break;
	case DIAMOND:/*TODO*/
		double hheight = Math.sqrt(min*min - min*min/4);
		Point2D pu = new Point2D(x, y-hheight);
		Point2D pl = new Point2D(x-min/2, y);
		Point2D pr = new Point2D(x+min/2, y);
		Point2D pd = new Point2D(x, y+hheight);
		s = new Polygon(pu.getX(), pu.getY(), pl.getX(), pl.getY(), pd.getX(), pd.getY(), pr.getX(), pr.getY());

		break;
	case STAR:/*TODO*/
		
		break;
	
	}
	return (Shape) s;
}
   
  public static void displayWorld(Object pane) {
    	// ((GridPane) pane).setPrefSize(10,10);
    
    	
    	for(int y = 0; y < Params.WORLD_HEIGHT;y++)
    	{
    		for(int x = 0; x <Params.WORLD_WIDTH; x++ )
    		{

    			if(OldMap.get(x+ SPACE + y) == null)
    					{/*Put Something White*/}

    				else {
    					Node node = createShape(x,y);
    					if(OldMap.get(x+ SPACE + y).viewShape() == CritterShape.STAR){
    						/*DOWN*/
    						
    						Shape s = new Rectangle();
    						
    						int min = Math.min(1400/Params.WORLD_WIDTH, 600/Params.WORLD_WIDTH);
    						double hheight = Math.sqrt(min*min - min*min/4);
    						Point2D pu = new Point2D(x, y-hheight);
    						Point2D pl = new Point2D(x-min/2, y);
    						Point2D pr = new Point2D(x+min/2, y);
    						Point2D pd = new Point2D(x, y+hheight);
    						
    						
    						/*ACROSS*/
    						int x_dif = (x-min/2)-(x+min/2);
    						int y_dif = 0;
    						double wwidth = Math.sqrt(x_dif*x_dif);
    						Point2D Acl = new Point2D(pd.getX()-wwidth/2,hheight/2-pd.getY());
    						Point2D Acu = new Point2D(pd.getX(),(hheight)/1.5-pd.getY());
    						Point2D Acr = new Point2D(pd.getX()+wwidth/2,hheight/2-pd.getY());
    						Point2D Acd = new Point2D(pd.getX(),(hheight)/.75-pd.getY());
    						s = new Polygon(Acl.getX(), Acl.getY(), Acu.getX(), Acu.getY(), Acr.getX(), Acr.getY(), Acd.getX(), Acd.getY());
    						node = s;
    					}
    					
    					((GridPane) pane).add(node,x,y);
    					}
					}
    			
    				
					
    		}
    		
    	}
    	
    
    
/*END OF PROJECT 5 REST IS UNCHANGED*/
    private int energy = 0;

    private int x_coord;
    private int y_coord;
    private  String[] Orig_Coord  = {"-1"};
    private static boolean LookIs_Called_In_Fight = false;
    private void resetOrig_Coord() {Orig_Coord[0] = "-1"; } //to be called when updating population

    private static List<Critter> population = new ArrayList<Critter>();
    private static List<Critter> babies = new ArrayList<Critter>();
 //new_added_methods
    private  void setEnergy(int x){energy = x;}
   private  void setX_coord(int into){x_coord = into;}
    private  void setY_coord(int into){y_coord = into;}
    private static Map<String,Critter>  OldMap = new HashMap<String,Critter>(); //USED IN CREATE DISPLAUWORLD  RESOLVE REMOVEDEAD
    private static Map<String, ArrayList<Critter>> NewMap = new HashMap<String, ArrayList<Critter>>(); //used to decrease time complexity in CheckEncounters and UpdateMap
    

    private boolean HasMoved = false;
    
    private void EvalHasMovedBefore(boolean new_HasMoved)
    {
    	HasMoved = new_HasMoved;
    }
    private boolean GetHasMovedBefore()
    {
    	return HasMoved;
    }
    private static final String SPACE = " ";
   private  int getX_coord(){return x_coord ;}
    private  int getY_coord(){return y_coord ;}
  
    /* Gets the package name.  This assumes that Critter agetYnd its
     * subclasses are all in the same package. */
    private static String myPackage;

    static {
        myPackage = Critter.class.getPackage().toString().split(" ")[1];
    }

    private static Random rand = new Random();

    public static int getRandomInt(int max) {
        return rand.nextInt(max);
    }

    public static void setSeed(long new_seed) {
        rand = new Random(new_seed);
    }

    /**
     * create and initialize a Critter subclass.
     * critter_class_name must be the unqualified name of a concrete
     * subclass of Critter, if not, an InvalidCritterException must be
     * thrown.
     *
     * @param critter_class_name
     * @throws InvalidCritterException
     */
    
    public static void createCritter(String critter_class_name) //THIS WORKS
            throws InvalidCritterException {
        // TODO: Complete this method
    	Object new_critter;
    	Method E;
	
    		try {
    	
			 new_critter = Class.forName(myPackage + "." + critter_class_name).newInstance();
			//System.out.println(Class.forName(myPackage + "." + critter_class_name));
			 E = new_critter.getClass().getSuperclass().getDeclaredMethod("setEnergy",int.class);
			 E.setAccessible(true);
			 	
		    	E.invoke(new_critter,Params.START_ENERGY);
		    	E = new_critter.getClass().getSuperclass().getDeclaredMethod("setX_coord",int.class);
		    	 E.setAccessible(true);
		    	 int x = getRandomInt(Params.WORLD_WIDTH);//int x
		    	 
		    	E.invoke(new_critter, x);
		    	E = new_critter.getClass().getSuperclass().getDeclaredMethod("setY_coord",int.class);
		    	  E.setAccessible(true);
		    	  int y = getRandomInt(Params.WORLD_HEIGHT);//int y
		    	  
		    	E.invoke(new_critter,y);
		    	population.add((Critter)new_critter);
		    	if(OldMap.get(x+ SPACE + y) == null  ) {OldMap.put(x+ SPACE + y, (Critter)new_critter);} //display if its first
		 
		    	if(NewMap.get(x+SPACE+y)  == null) {NewMap.put(x+SPACE+y,new ArrayList<Critter>());} //same as OldMap
		    	NewMap.get(x+ SPACE + y).add((Critter) new_critter);
		    	
		    	
            
    		}
    		catch(InstantiationException | IllegalAccessException | ClassNotFoundException  e) {throw new InvalidCritterException(critter_class_name);} 
    		catch (NoSuchMethodException|SecurityException|IllegalArgumentException | InvocationTargetException e) { //method exception handling
				// TODO Auto-generated catch block
				//e.printStackTrace();
    			throw new InvalidCritterException(critter_class_name);
			} 
			
		
		
     
    	
    }

    /**
     * Gets a list of critters of a specific type.
     *
     * @param critter_class_name What kind of Critter is to be listed.
     *        Unqualified class name.
     * @return List of Critters.
     * @throws InvalidCritterException
     */
    public static List<Critter> getInstances(String critter_class_name) 
            throws InvalidCritterException {
        // TODO: Complete this method
       List<Critter> yomomma = new ArrayList<Critter>();
    	//List<Critter> population = Critter.getPopulation();
    	Object myCrit = new Object();
		try {
			myCrit = Class.forName(myPackage + "." + critter_class_name).newInstance();
		
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			throw new InvalidCritterException(critter_class_name);
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			throw new InvalidCritterException(critter_class_name);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			throw new InvalidCritterException(critter_class_name);
		}
	   
    	for (Critter crit: population) { 
    	if (myCrit.getClass().isInstance(crit)) { 
    	yomomma.add(crit);
    	}
    	}
    	return yomomma;
    }

    /**
     * Clear the world of all critters, dead and alive
     */
    public static void clearWorld() {
        // TODO: Complete this method
    	population.clear();
    	babies.clear();
    	OldMap.clear();
    	NewMap.clear();
    	
    }
    /*HELPER FUNCTIONS*/
    private static String getCoords(Critter crit) 
    {
    	Method m_x;
		Method m_y;
		int x = -1;
		int y = -1;
			try {
				m_x = crit.getClass().getSuperclass().getDeclaredMethod("getX_coord");
				m_x.setAccessible(true);
				m_y = crit.getClass().getSuperclass().getDeclaredMethod("getY_coord");
				m_y.setAccessible(true);
					 x = (int) m_x.invoke(crit);
					 y = (int) m_y.invoke(crit);
			} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				
			}
			return x + SPACE + y;
    }
    private static void setCoords(Critter crit,String key)
    {
    	Method m_x;
		Method m_y;
		int x = -1;
		int y = -1;
			try {
				m_x = crit.getClass().getSuperclass().getDeclaredMethod("setX_coord",int.class);
				m_x.setAccessible(true);
				m_y = crit.getClass().getSuperclass().getDeclaredMethod("setY_coord", int.class);
				m_y.setAccessible(true);
				int val_x = Integer.valueOf(key.substring(0,key.indexOf(SPACE)));
				int val_y = Integer.valueOf(key.substring(key.indexOf(SPACE)+1));
					  m_x.invoke(crit,val_x);
					m_y.invoke(crit,val_y);
			} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			}
			
    }
  private static void ResetOrig_CoordInWorldTimeStep(Critter A)
  {
	  Method Orig_Coord;
		try {
			Orig_Coord = A.getClass().getSuperclass().getDeclaredMethod("resetOrig_Coord");
			Orig_Coord.setAccessible(true);
  		Orig_Coord.invoke(A, null);
		} catch (NoSuchMethodException | SecurityException | IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  }
   
    private static void Remove_Dead() 
    {
        	
    	for(int x = 0; x < population.size();x++) 
    	{
    		int energy = population.get(x).getEnergy();
    		if(energy <= 0) {population.remove(x);x-=1;} //doesnt skip over anything
    		
    	}
    	
    	}
    /*private static void RemoveDeadAfterDoTimeStep() 
    {

   	 for (Map.Entry<String,ArrayList<Critter>> entry : NewMap.entrySet())
   	 {  

   	 int iterator = 0;
   	 while(iterator <  entry.getValue().size())
   	 	{
   		 	Critter crit = entry.getValue().get(iterator);
   		 	if(crit.getEnergy() <= 0) //CULL DEAD AND CONTINUE
   		 		{entry.getValue().remove(iterator);continue;}
   		 	iterator++;
   		 	
   	 	}
   	 
   	 	 
   	 }
   	 
    }*/
    
    private static void Check_forEncounters() //ON^2 MODDED FUNCTION
    {
    	
    	 for (Map.Entry<String,ArrayList<Critter>> entry : NewMap.entrySet())
    	 {  
    	 ArrayList<Critter> fighters = new ArrayList<Critter>();
    	 for(Critter crit: entry.getValue())
    	 	{
    			 fighters.add(crit); //add potential fighter 
    			 //only thing changed is removed conditional
    	 	}
    	 
    	 	doEncounters(fighters,entry.getKey());
    	 	 
    	 }
 	
    }
    private static void UpdateNewMap()
    {
   
    	NewMap.clear();
        for(Critter crit : population) 
    		{
        	String key = getCoords(crit);
        	/*NewMap ADDITION*/
        	if(NewMap.get(key) == null)
        	{NewMap.put(key, new ArrayList<Critter>() );}
        	NewMap.get(key).add(crit);
    		
    		}
    }
    private static void UpdateOldMap()
    {
    	OldMap.clear();
        for(Critter crit : population) 
    		{
        	String key = getCoords(crit);
        	if(OldMap.get(key) == null)
        		{OldMap.put(key, crit);}  		
    		}
    }
    /*END OF HELPER FUNCTIONS*/
    public static void worldTimeStep() { //MODDED FUNCTION
        // TODO: Complete this method
    	NewMap.clear();
        for(Critter crit : population) 
    		{
        	String key_before = getCoords(crit);
        	crit.doTimeStep();
        	String key_after = getCoords(crit);
        	
    			try {

    				Method Move = crit.getClass().getSuperclass().getDeclaredMethod("EvalHasMovedBefore",boolean.class);
    				Move.setAccessible(true);
    				if(key_before.equals(key_after))
    					{Move.invoke(crit,false);}
    				else
    					{Move.invoke(crit,true);}
    				
					Method Energy = crit.getClass().getSuperclass().getDeclaredMethod("setEnergy",int.class);
					Energy.setAccessible(true);
					Energy.invoke(crit, crit.getEnergy()-Params.REST_ENERGY_COST); 
					if(crit.getEnergy() > 0) { //only adds alive crit
						if(NewMap.get(key_after) == null) {NewMap.put(key_after, new ArrayList<Critter>());} //updates NewMap
						NewMap.get(key_after).add(crit);}
				} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
					// TODO Auto-generated catch block
					
				}			

    		}
     
       UpdateOldMap(); //Reference During Encounter MODDED LINE
       LookIs_Called_In_Fight = true; //Sets LookIs_Called_In_Fight to true
       /*DOEncounter*/
       Check_forEncounters(); 
       LookIs_Called_In_Fight = false; //Resets it Back to False
        Remove_Dead(); //Removes dead from population and resets Orig_Coord
        
    	for(int x = 0; x < babies.size();x++)//adds babies
    	{population.add(babies.get(x));}
    	for(int x = 0; x < population.size(); x++)
    	{ResetOrig_CoordInWorldTimeStep(population.get(x)); //Reset Orig_Coord in finalized updated population
    	}
    	
    	/*UpdateNewMap*/ 
		UpdateNewMap();
    		
    	
    }
  //new method
    
    private static void print_first_border() { //WORKS
    	
    	for(int x = 0; x < Params.WORLD_WIDTH+2;x++) 	//print first border
    	{if(x == 0 || x ==  Params.WORLD_WIDTH+1)
    	{System.out.print("+");}
    	else {System.out.print("-");}
    	}
    	System.out.println();
    }
    
    public static void displayprintWorld() { //WORKS
        // TODO: Complete this method
        print_first_border();
     
      
 
    	for(int y = 0; y < Params.WORLD_HEIGHT;y++)
    	{
    		System.out.print("|");
    		for(int x = 0; x <Params.WORLD_WIDTH; x++ )
    		{
    				if(OldMap.get(x+ SPACE + y) != null)
    					{System.out.print(OldMap.get(x+ SPACE + y));}
    				else {System.out.print(" ");}
    				
    		}
    		System.out.println("|");
    	}
    	
    	print_first_border();
    }
    

    /**
     * Prints out how many Critters of each type there are on the
     * board.
     *
     * @param critters List of Critters.
     */
    /*public static void runStats(List<Critter> critters) {
        System.out.print("" + critters.size() + " critters as follows -- ");
        Map<String, Integer> critter_count = new HashMap<String, Integer>();
        for (Critter crit : critters) {
            String crit_string = crit.toString();
            critter_count.put(crit_string,
                    critter_count.getOrDefault(crit_string, 0) + 1);
        }
        String prefix = "";
        for (String s : critter_count.keySet()) {
            System.out.print(prefix + s + ":" + critter_count.get(s));
            prefix = ", ";
        }
        System.out.println();
    }*/

    public abstract void doTimeStep();

    public abstract boolean fight(String oponent);

    /* a one-character long string that visually depicts your critter
     * in the ASCII interface */
    public String toString() {
        return "";
    }

    protected int getEnergy() {
        return energy;
    }
   private void checkbounds() { //MUST TEST
	   if(x_coord == Params.WORLD_WIDTH)
	   {x_coord =0;}
	   else if(x_coord == -1)
	   {x_coord = Params.WORLD_WIDTH-1;}
	  
	   if(y_coord == Params.WORLD_HEIGHT)
	   {y_coord =0;}
	   else if(y_coord == -1)
	   {y_coord =Params.WORLD_HEIGHT-1;}
	   
   }
    protected final void walk(int direction) {
        // TODO: Complete this method
        	Params param = new Params();
        	if(Orig_Coord[0].equals("-1"))
			{Orig_Coord[0] = x_coord+ SPACE + y_coord;}
    	if(direction == 0) {x_coord+=1;} //go right
    	else if(direction == 1) {x_coord+=1; y_coord-=1;} //diagonal up adn right
    	else if(direction == 2) {y_coord-=1;} //stragiht up
    	else if(direction == 3) {x_coord-=1; y_coord-=1;} //up and left;
    	else if(direction == 4) {x_coord-=1;} //left
    	else if(direction == 5) {x_coord-=1;y_coord+=1;} //down and left;
    	else if(direction == 6) {y_coord+=1;} //down
    	else if(direction == 7) {x_coord+=1;y_coord+=1;} //down and right
    	energy-= param.WALK_ENERGY_COST;
    	checkbounds();
    	
    }
    private static void Resolve(Critter A,Critter B)
    {
    	Method E;
    
		try {
			
			E = A.getClass().getSuperclass().getDeclaredMethod("setEnergy", int.class);
			E.setAccessible(true);
			E.invoke(A, A.getEnergy()+ B.getEnergy()/2);//reward half of the winners energy

		
			E = B.getClass().getSuperclass().getDeclaredMethod("setEnergy", int.class);
			E.setAccessible(true);
			E.invoke(B, 0); // B = dead
			
			String key = getCoords(A);
			//OldMap.put(key,A);//forDisplay
			
		
		} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
	
    }
    private static boolean GetHasMovedBeforeFinal(Critter crit)
    {
    	boolean output = false;
    	try {
			Method Move = crit.getClass().getSuperclass().getDeclaredMethod("GetHasMovedBefore");
			Move.setAccessible(true);
			output = (boolean) Move.invoke(crit);
		} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e1) {
			// TODO Auto-generated catch block
			//e1.printStackTrace();
		}
    	return output;
    }
    
    private static void EvalMoveinFight(Critter A, Critter B,String key)
    {
    
    	boolean A_true = false; //if A ran from fight
    	if(!getCoords(A).equals(key) ) //if A walks/runs 
    	{
    		
    	if(NewMap.get(getCoords(A)) == null && !GetHasMovedBeforeFinal(A)) //if empty space and not walked before
    	{A_true = true;} //Updates A position
    	else{setCoords(A,key);}//RESET
    	}
    	
    	/*EVALB*/
 
    	if(!getCoords(B).equals(key) && !GetHasMovedBeforeFinal(B)) //if B moved and/or didnt invoked walk/run before
    	{
    		if(NewMap.get(getCoords(B)) != null ||  ( A_true && getCoords(B).equals(getCoords(A))) ) //if occupied  space OR  A ran and is in  same space
    		{setCoords(B,key);}
    		
    	}
    	
    	
    }
    private static void doEncounters(ArrayList<Critter> fighters,String key) //WORKS O(N) MODDED FUNCTION
    {
    	if(fighters.size() <= 1) 
    	{return;}
    	
    	Critter A = fighters.get(0);
    	Critter B = fighters.get(1);
    	boolean A_fight = A.fight(B.toString());
    	boolean B_fight = B.fight(A.toString());
    
    	EvalMoveinFight(A,B,key);
  
    	if(getCoords(A).equals(getCoords(B))) {
    	if(A.getEnergy() > 0 & B.getEnergy() > 0)
    	{
    		
    		int A_Dice;
    		int B_Dice;
    		if(A_fight)
    			{ A_Dice = getRandomInt(A.getEnergy());}
    		else {A_Dice = 0;}
    		
    		if(B_fight)
			{ B_Dice = getRandomInt(B.getEnergy());}
		else {B_Dice = 0;}
    	
	
    		if(A_Dice >= B_Dice)
    		{Resolve( A, B); //A=Winner; B =Loser;
    		}
    		
    		else
    		{Resolve( B, A); //A=Winner; B =Loser;
    	
    		}
    		
    	}
    	}
    	/* Gulag time*/
			
		
    	if(A.getEnergy() <= 0  || !getCoords(A).equals(key)) //or if A moved
    	{fighters.remove(0); 
    	if(B.getEnergy() <=0|| !getCoords(B).equals(key) ) {fighters.remove(0);}
    	}
    	else if(B.getEnergy() <= 0 || !getCoords(B).equals(key)) //or if B moved
    	{fighters.remove(1); }
    	/*CULL DEAD */
    	//RemoveDeadInFight(A,B); //MODDED LINE
    	
    	doEncounters(fighters,key);  //recursive call; fights two at a time
    	
    }
    /*
  private static void RemoveDeadInFight(Critter A, Critter B)
  {
	  if(A.getEnergy() <= 0)
  	{NewMap.get(getCoords(A)).remove(A);}
  	if(B.getEnergy() <= 0)
  	{NewMap.get(getCoords(B)).remove(B);}
  	
  }
  */
    
    protected final void run(int direction) { //MUSTTEST
        // TODO: Complete this method
    	Params param = new Params();
    	int consto = direction;
    	walk(consto);
    	walk(consto);
    	energy +=(2*param.WALK_ENERGY_COST); //reset energy
    	energy-= param.RUN_ENERGY_COST; // subtract Run energy
    
    	
    }
  
    protected final void reproduce(Critter offspring, int direction) { //MUST TEST
        // TODO: Complete this method
    	
    	//Create new critter offspring class of class subty
    	
    	try {
    		if(energy < Params.MIN_REPRODUCE_ENERGY){return;}//Check energy_parent >= MIN_REPRODUCE_ENERGY 
			Method E;
			
			//Energy calc 
	    	int energy_child = (int) Math.floor(energy/2);
	    	energy= (int) Math.ceil(energy/2);//(round down child/2 round up parent/2
	    	
	    
	    	//set offspring to  current x and y cord; 
	    	E = offspring.getClass().getSuperclass().getDeclaredMethod("setX_coord",int.class);
	    	E.setAccessible(true);
	    	E.invoke(offspring, x_coord); 
	    	E = offspring.getClass().getSuperclass().getDeclaredMethod("setY_coord",int.class);
	    	E.setAccessible(true);
	    	E.invoke(offspring, y_coord); 
	    	
	    	
	    
	    	//invoke walk, reset energy
	    		offspring.walk(direction); 
	    		E = offspring.getClass().getSuperclass().getDeclaredMethod("setEnergy",int.class);
	    		E.setAccessible(true);E.invoke(offspring, energy_child);  //energy is what its sopposed to be
	    		babies.add(offspring);
	    	
	    	
		} catch (NoSuchMethodException|SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
    	
    	
    }
   

    /**
     * The TestCritter class allows some critters to "cheat". If you
     * want to create tests of your Critter model, you can create
     * subclasses of this class and then use the setter functions
     * contained here.
     * <p>
     * NOTE: you must make sure that the setter functions work with
     * your implementation of Critter. That means, if you're recording
     * the positions of your critters using some sort of external grid
     * or some other data structure in addition to the x_coord and
     * y_coord functions, then you MUST update these setter functions
     * so that they correctly update your grid/data structure.
     */
    static abstract class TestCritter extends Critter {

        protected void setEnergy(int new_energy_value) {
            super.energy = new_energy_value;
        }

        protected void setX_coord(int new_x_coord) {
            super.x_coord = new_x_coord;
        }

        protected void setY_coord(int new_y_coord) {
            super.y_coord = new_y_coord;
        }

        protected int getX_coord() {
            return super.x_coord;
        }

        protected int getY_coord() {
            return super.y_coord;
        }
        protected void EvalHasMovedBefore(boolean new_HasMoved)
        {
        	super.HasMoved = new_HasMoved;
        }
        protected boolean GetHasMovedBefore()
        {
        	return super.HasMoved;
        }
        protected void resetOrig_Coord() {super.Orig_Coord[0] = "-1"; } //reset when updating population
        protected String getOrig_Coord() {return super.Orig_Coord[0];}

        /**
         * This method getPopulation has to be modified by you if you
         * are not using the population ArrayList that has been
         * provided in the starter code.  In any case, it has to be
         * implemented for grading tests to work.
         */
        protected static List<Critter> getPopulation() {
            return population;
        }

        /**
         * This method getBabies has to be modified by you if you are
         * not using the babies ArrayList that has been provided in
         * the starter code.  In any case, it has to be implemented
         * for grading tests to work.  Babies should be added to the
         * general population at either the beginning OR the end of
         * every timestep.
         */
        protected static List<Critter> getBabies() {
            return babies;
        }
    }
}
