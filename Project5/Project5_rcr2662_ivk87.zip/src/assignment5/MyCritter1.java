package assignment5;
//d
import java.util.List;

import assignment5.Critter.CritterShape;
import assignment5.Critter.TestCritter;

public class MyCritter1 extends Critter {

    @Override
    public String toString() {
        return "1";
    }

    private static final int GENE_TOTAL = 24;
    private int[] genes = new int[8];
    private int dir;

    public MyCritter1() {
        for (int k = 0; k < 8; k += 1) {
            genes[k] = GENE_TOTAL / 8;
        }
        dir = Critter.getRandomInt(8);
    }

    public boolean fight(String not_used) {
    	boolean steps = false;
    	switch(Critter.getRandomInt(2)) {
    		case 0:
    			steps = false;
    			break;
    		case 1:
    			steps = true;
    			break;
    	}
    	look(Critter.getRandomInt(8),steps);
        return true;
    }

    @Override
    public void doTimeStep() {
        /* take one step forward */
    	boolean steps = false;
    	switch(Critter.getRandomInt(2)) {
    		case 0:
    			steps = false;
    			break;
    		case 1:
    			steps = true;
    			break;
    			 
    	}
    	walk(Critter.getRandomInt(8));
    }

    public static String runStats(List<Critter> MyCritter1s) {
        String str = "";
        int total_straight = 0;
        int total_left = 0;
        int total_right = 0;
        int total_back = 0;
        for (Object obj : MyCritter1s) {
            MyCritter1 c = (MyCritter1) obj;
            total_straight += c.genes[0];
            total_right += c.genes[1] + c.genes[2] + c.genes[3];
            total_back += c.genes[4];
            total_left += c.genes[5] + c.genes[6] + c.genes[7];
        }
        str += ("" + MyCritter1s.size() + " total MyCritter1s    \n");
        str += ("" + total_straight / (GENE_TOTAL * 0.01 * MyCritter1s.size()) + "% straight   \n");
        str += ("" + total_back / (GENE_TOTAL * 0.01 * MyCritter1s.size()) + "% back   \n");
        str += ("" + total_right / (GENE_TOTAL * 0.01 * MyCritter1s.size()) + "% right   \n");
        str += ("" + total_left / (GENE_TOTAL * 0.01 * MyCritter1s.size()) + "% left   \n");
        return str;
    }

    @Override
    public CritterShape viewShape() {
        return CritterShape.SQUARE;
    }

    @Override
    public javafx.scene.paint.Color viewOutlineColor() {
        return javafx.scene.paint.Color.BLUE;
    }
}
