This file is a placeholder.

A placeholder file is needed to ensure that git continues tracking the directory
this file is in. Otherwise, this directory would not be a part of the repository
and people who checkout the repository would not have this directory created.

Both Maven and the grading script expect the existence of this directory.
