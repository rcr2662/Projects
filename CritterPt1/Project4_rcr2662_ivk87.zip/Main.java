 /*
 * CRITTERS Main.java
 * EE422C Project 4 submission by
 * Replace <...> with your actual data.
 * Roberto Reyes
 * rcr2662 
 * 17360
 * Ishan
 * Ivk87
 * <Student2 5-digit Unique No.>
 * Slip days used: <0>
 * Spring 2022
 */

package assignment4;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;
import java.util.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/*
* Usage: java <pkg name>.Main <input file> test input file is
* optional.  If input file is specified, the word 'test' is optional.
* May not use 'test' argument without specifying input file.
*/

public class Main {

   /* Scanner connected to keyboard input, or input file */
   static Scanner kb;

   /* Input file, used instead of keyboard input if specified */
   private static String inputFile;

   /* If test specified, holds all console output */
   static ByteArrayOutputStream testOutputString;

   /* Use it or not, as you wish! */
   private static boolean DEBUG = false;

   /* if you want to restore output to console */
   static PrintStream old = System.out;

   /* Gets the package name.  The usage assumes that Critter and its
      subclasses are all in the same package. */
   private static String myPackage; // package of Critter file.

   /* Critter cannot be in default pkg. */
   static {
       myPackage = Critter.class.getPackage().toString().split(" ")[1];
   }

   /**
    * Main method.
    *
    * @param args args can be empty.  If not empty, provide two
    *             parameters -- the first is a file name, and the
    *             second is test (for test output, where all output
    *             to be directed to a String), or nothing.
    */
   public static void main(String[] args) {
       if (args.length != 0) {
           try {
               inputFile = args[0];
               kb = new Scanner(new File(inputFile));
           } catch (FileNotFoundException e) {
               System.out.println("USAGE: java <pkg name>.Main OR java <pkg name>.Main <input file> <test output>");
               e.printStackTrace();
           } catch (NullPointerException e) {
               System.out.println("USAGE: java <pkg name>.Main OR java <pkg name>.Main <input file> <test output>");
           }
           if (args.length >= 2) {
               /* If the word "test" is the second argument to java */
               if (args[1].equals("test")) {
                   /* Create a stream to hold the output */
                   testOutputString = new ByteArrayOutputStream();
                   PrintStream ps = new PrintStream(testOutputString);
                   /* Save the old System.out. */
                   old = System.out;
                   /* Tell Java to use the special stream; all
                    * console output will be redirected here from
                    * now */
                   System.setOut(ps);
               }
           }
       } else { // If no arguments to main
           kb = new Scanner(System.in); // Use keyboard and console
       }
       commandInterpreter(kb);

       System.out.flush();
   }

   /* Do not alter the code above for your submission. */
private static ArrayList<String>  set_Tester(Scanner kb)
{
   ArrayList<String> tester =  new ArrayList<String>();
   String cuck[] = kb.nextLine().split(" ");
   for(int y = 0; y < cuck.length; y++)
   {
       tester.add(cuck[y]);
   }
   return tester;
}
private static void DoCreate(ArrayList<String> tester) {
   
   int numtimes = 1;
   if(tester.size() > 2)
   { numtimes = Integer.valueOf(tester.get(2));}
for(int x = 0; x < numtimes;x++)
{
	
	try {
	    Critter.createCritter(tester.get(1));
	} catch (InvalidCritterException e) {
		InvalidCritterExceptionTime(tester);
        }
}
   }
private static void InvalidCritterExceptionTime(ArrayList<String> tester)
{System.out.println("error processing: " + String.join(" ", tester));}

    private static void commandInterpreter(Scanner kb) //Finish Stage 3 Exception handling stuff and Stage 2 Clover
    {
        //TODO Implement this method
    	ArrayList<String> tester =  new ArrayList<String>();
    	tester = set_Tester(kb);
    	String input = tester.get(0); 
        
    		while(!input.equals("quit")) {
    			 try {  
    		if(input.equals("show")){
                if(tester.size() > 1) {throw new InvalidCritterException(tester.toString());}
                Critter.displayWorld();
                }
    		else if(input.equals("create")){
                if(tester.size() > 3) {throw new InvalidCritterException(tester.toString());}
                DoCreate(tester);
                }
    		else if(input.equals("step"))
    		{
                if(tester.size() > 2) {throw new InvalidCritterException(tester.toString());}
                ArrayList<String> clovers =  new ArrayList<String>();
                clovers.add("create");clovers.add("Clover");clovers.add(Params.REFRESH_CLOVER_COUNT + "");
    			int numtimes = 1;
    			if(tester.size() >1) {numtimes = Integer.valueOf(tester.get(1));}
    		
            	for(int x = 0; x < numtimes;x++){
                    Critter.worldTimeStep();
                    DoCreate(clovers);
                }
    		}
    		else if(input.equals("stats"))
    		{
                if(tester.size() > 2) {throw new InvalidCritterException(tester.toString());}
    			if(tester.size() == 1) { }
    			else {
    				
						List<Critter> Dummy = Critter.getInstances(tester.get(1));
					Class clazz = Class.forName(myPackage+"." + tester.get(1));
						Method E = clazz.getDeclaredMethod("runStats",List.class);
						E.invoke(null,Dummy);
				
					
    			}
    		}
    		else if(input.equals("seed"))
    		{
                if(tester.size() > 2) {throw new InvalidCritterException(tester.toString());}
    			if(tester.size() == 1)
    				{Critter.setSeed((long) 1);}
    			else {Critter.setSeed((long) Integer.valueOf(tester.get(1))  );}
    			
    		}
    		else if(input.equals("clear")){
                if(tester.size() > 1) {throw new InvalidCritterException(tester.toString());}
                Critter.clearWorld();
                }
    		
    		if(input.equals("quit") & tester.size() > 1) {throw new InvalidCritterException(tester.toString());}
    		
    		}catch (InvalidCritterException | ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e){
                InvalidCritterExceptionTime(tester);
            }

    	tester.clear();
    	tester = set_Tester(kb);
	    input = tester.get(0);
    		}
        
        
        
    	
    }
  
}
