 /*
 * CRITTERS Main.java
 * EE422C Project 4 submission by
 * Replace <...> with your actual data.
 * Roberto Reyes
 * rcr2662 
 * 17360
 * Ishan
 * Ivk87
 * <Student2 5-digit Unique No.>
 * Slip days used: <0>
 * Spring 2022
 */

package assignment4;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;


/* 
 * See the PDF for descriptions of the methods and fields in this
 * class. 
 * You may add fields, methods or inner classes to Critter ONLY
 * if you make your additions private; no new public, protected or
 * default-package code or data can be added to Critter.
 */

public abstract class Critter {

    private int energy = 0;

    private int x_coord;
    private int y_coord;

    private static List<Critter> population = new ArrayList<Critter>();
    private static List<Critter> babies = new ArrayList<Critter>();
 //new_added_methods
    private  void setEnergy(int x){energy = x;}
   private  void setX_coord(int into){x_coord = into;}
    private  void setY_coord(int into){y_coord = into;}
    private static Map<String,Critter>  WorldMap = new HashMap<String,Critter>(); //USED IN CREATE DISPLAUWORLD  RESOLVE REMOVEDEAD
    private static Map<String, ArrayList<Critter>> SpeedMap = new HashMap<String, ArrayList<Critter>>(); //used to decrease time complexity in CheckEncounters and UpdateMap

	
    private boolean HasMoved = false;
    
    private void EvalHasMovedBefore(boolean new_HasMoved)
    {
    	HasMoved = new_HasMoved;
    }
    private boolean GetHasMovedBefore()
    {
    	return HasMoved;
    }
    private static final String SPACE = " ";
   private  int getX_coord(){return x_coord ;}
    private  int getY_coord(){return y_coord ;}
    /* Gets the package name.  This assumes that Critter agetYnd its
     * subclasses are all in the same package. */
    private static String myPackage;

    static {
        myPackage = Critter.class.getPackage().toString().split(" ")[1];
    }

    private static Random rand = new Random();

    public static int getRandomInt(int max) {
        return rand.nextInt(max);
    }

    public static void setSeed(long new_seed) {
        rand = new Random(new_seed);
    }

    /**
     * create and initialize a Critter subclass.
     * critter_class_name must be the unqualified name of a concrete
     * subclass of Critter, if not, an InvalidCritterException must be
     * thrown.
     *
     * @param critter_class_name
     * @throws InvalidCritterException
     */
    
    public static void createCritter(String critter_class_name) //THIS WORKS
            throws InvalidCritterException {
        // TODO: Complete this method
    	Object new_critter;
    	Method E;
	
    		try {
			 new_critter = Class.forName(myPackage + "." + critter_class_name).newInstance();
			
			 E = new_critter.getClass().getSuperclass().getDeclaredMethod("setEnergy",int.class);
			 E.setAccessible(true);
			 	
		    	E.invoke(new_critter,Params.START_ENERGY);
		    	E = new_critter.getClass().getSuperclass().getDeclaredMethod("setX_coord",int.class);
		    	 E.setAccessible(true);
		    	 int x = getRandomInt(Params.WORLD_WIDTH);//int x
		    	E.invoke(new_critter, x);
		    	E = new_critter.getClass().getSuperclass().getDeclaredMethod("setY_coord",int.class);
		    	  E.setAccessible(true);
		    	  int y = getRandomInt(Params.WORLD_HEIGHT);//int y
		    	E.invoke(new_critter,y);
		    	population.add((Critter)new_critter);
		    	if(WorldMap.get(x+ SPACE + y) == null  ) {WorldMap.put(x+ SPACE + y, (Critter)new_critter);} //display if its first
		 
		    	if(SpeedMap.get(x+SPACE+y)  == null) {SpeedMap.put(x+SPACE+y,new ArrayList<Critter>());} //same as worldMap
		    	SpeedMap.get(x+ SPACE + y).add((Critter) new_critter);
		    	
		    	
            
    		}
    		catch(InstantiationException | IllegalAccessException | ClassNotFoundException  e) {throw new InvalidCritterException(critter_class_name);} 
    		catch (NoSuchMethodException|SecurityException|IllegalArgumentException | InvocationTargetException e) { //method exception handling
				// TODO Auto-generated catch block
				//e.printStackTrace();
    			throw new InvalidCritterException(critter_class_name);
			} 
			
		
		
     
    	
    }

    /**
     * Gets a list of critters of a specific type.
     *
     * @param critter_class_name What kind of Critter is to be listed.
     *        Unqualified class name.
     * @return List of Critters.
     * @throws InvalidCritterException
     */
    public static List<Critter> getInstances(String critter_class_name) //MUST TESTst
            throws InvalidCritterException {
        // TODO: Complete this method
       List<Critter> yomomma = new ArrayList<Critter>();
    	//List<Critter> population = Critter.getPopulation();
    	Object myCrit = new Object();
		try {
			myCrit = Class.forName(myPackage + "." + critter_class_name).newInstance();
		
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			throw new InvalidCritterException(critter_class_name);
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			throw new InvalidCritterException(critter_class_name);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			throw new InvalidCritterException(critter_class_name);
		}
	   
    	for (Critter crit: population) { 
    	if (myCrit.getClass().isInstance(crit)) { 
    	yomomma.add(crit);
    	}
    	}
    	return yomomma;
    }

    /**
     * Clear the world of all critters, dead and alive
     */
    public static void clearWorld() {
        // TODO: Complete this method
    	population.clear();
    	babies.clear();
    	WorldMap.clear();
    	SpeedMap.clear();
    }
    private static void Remove_Dead() //MUST TEST
{
    	
	for(int x = 0; x < population.size();x++) 
	{
		int energy = population.get(x).getEnergy();
		if(energy <= 0) {population.remove(x);x-=1;} //doesnt skip over anything
		
	}
	
	}
    private static String getCoords(Critter crit) 
    {
    	Method m_x;
		Method m_y;
		int x = -1;
		int y = -1;
			try {
				m_x = crit.getClass().getSuperclass().getDeclaredMethod("getX_coord");
				m_x.setAccessible(true);
				m_y = crit.getClass().getSuperclass().getDeclaredMethod("getY_coord");
				m_y.setAccessible(true);
					 x = (int) m_x.invoke(crit);
					 y = (int) m_y.invoke(crit);
			} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				
			}
			return x + SPACE + y;
    }
    private static void setCoords(Critter crit,String key)
    {
    	Method m_x;
		Method m_y;
		int x = -1;
		int y = -1;
			try {
				m_x = crit.getClass().getSuperclass().getDeclaredMethod("setX_coord",int.class);
				m_x.setAccessible(true);
				m_y = crit.getClass().getSuperclass().getDeclaredMethod("setY_coord", int.class);
				m_y.setAccessible(true);
				int val_x = Integer.valueOf(key.substring(0,key.indexOf(SPACE)));
				int val_y = Integer.valueOf(key.substring(key.indexOf(SPACE)+1));
					  m_x.invoke(crit,val_x);
					m_y.invoke(crit,val_y);
			} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			}
			
    }
    
    private static void Check_forEncounters() //MUST TEST ON^2
    {
    	
    	 for (Map.Entry<String,ArrayList<Critter>> entry : SpeedMap.entrySet())
    	 {  
    	 ArrayList<Critter> fighters = new ArrayList<Critter>();
    	 for(Critter crit: entry.getValue())
    	 	{
    		
    		 if(crit.getEnergy() > 0)
    			 {fighters.add(crit);} //add potential fighter 
    	 	}
    	 
    	 	doEncounters(fighters,entry.getKey());
    	 	 
    	 }
    	
    	
    			
    	
    }
    /*HELPER FUNCTION*/
    private static void UpdateMap()
    {
    	WorldMap.clear();
    	SpeedMap.clear();
        for(Critter crit : population) 
    		{
        	String key = getCoords(crit);
        	if(WorldMap.get(key) == null)
        		{WorldMap.put(key, crit);}
        	/*SPEEDMAP ADDITION*/
        	if(SpeedMap.get(key) == null)
        	{SpeedMap.put(key, new ArrayList<Critter>() );}
        	SpeedMap.get(key).add(crit);
    		
    		}
    }
    private static void UpdateDisplayMap()
    {
    	WorldMap.clear();
        for(Critter crit : population) 
    		{
        	String key = getCoords(crit);
        	if(WorldMap.get(key) == null)
        		{WorldMap.put(key, crit);}  		
    		}
    }
    
    public static void worldTimeStep() { //MUST TEST EVERYTHING HERE
        // TODO: Complete this method
    	SpeedMap.clear();
        for(Critter crit : population) 
    		{
        	String key_before = getCoords(crit);
        	crit.doTimeStep();
        	String key_after = getCoords(crit);
        	
    			try {

    				Method Move = crit.getClass().getSuperclass().getDeclaredMethod("EvalHasMovedBefore",boolean.class);
    				Move.setAccessible(true);
    				if(key_before.equals(key_after))
    					{Move.invoke(crit,false);}
    				else
    					{Move.invoke(crit,true);}
    				
					Method Energy = crit.getClass().getSuperclass().getDeclaredMethod("setEnergy",int.class);
					Energy.setAccessible(true);
					Energy.invoke(crit, crit.getEnergy()-Params.REST_ENERGY_COST); 
					
					if(SpeedMap.get(key_after) == null) {SpeedMap.put(key_after, new ArrayList<Critter>());} //updates SpeedMap
					SpeedMap.get(key_after).add(crit);
				} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
					// TODO Auto-generated catch block
					
				}			

    		}
      /*DOEncounter*/
       
       Check_forEncounters();  //ENCOUNTERS ONLY AFTER EVERYTHING DOES DO TIME STEP

        Remove_Dead(); //Removes dead
        
    	for(int x = 0; x < babies.size();x++)//adds babies
    	{population.add(babies.get(x));}
    	
    	/*UpdateMap*/ //AT THE VERY END UNNECESSARY
		UpdateMap();
    		
    	
    }
  //new method
    private static void print_first_border() { //WORKS
    	
    	for(int x = 0; x < Params.WORLD_WIDTH+2;x++) 	//print first border
    	{if(x == 0 || x ==  Params.WORLD_WIDTH+1)
    	{System.out.print("+");}
    	else {System.out.print("-");}
    	}
    	System.out.println();
    }
    public static void displayWorld() { //WORKS
        // TODO: Complete this method
        print_first_border();
     
        UpdateDisplayMap(); //UPDATE WORLDMAP
 
    	for(int y = 0; y < Params.WORLD_HEIGHT;y++)
    	{
    		System.out.print("|");
    		for(int x = 0; x <Params.WORLD_WIDTH; x++ )
    		{
    				if(WorldMap.get(x+ SPACE + y) != null)
    					{System.out.print(WorldMap.get(x+ SPACE + y));}
    				else {System.out.print(" ");}
    				
    		}
    		System.out.println("|");
    	}
    	
    	print_first_border();
    }

    /**
     * Prints out how many Critters of each type there are on the
     * board.
     *
     * @param critters List of Critters.
     */
    public static void runStats(List<Critter> critters) {
        System.out.print("" + critters.size() + " critters as follows -- ");
        Map<String, Integer> critter_count = new HashMap<String, Integer>();
        for (Critter crit : critters) {
            String crit_string = crit.toString();
            critter_count.put(crit_string,
                    critter_count.getOrDefault(crit_string, 0) + 1);
        }
        String prefix = "";
        for (String s : critter_count.keySet()) {
            System.out.print(prefix + s + ":" + critter_count.get(s));
            prefix = ", ";
        }
        System.out.println();
    }

    public abstract void doTimeStep();

    public abstract boolean fight(String oponent);

    /* a one-character long string that visually depicts your critter
     * in the ASCII interface */
    public String toString() {
        return "";
    }

    protected int getEnergy() {
        return energy;
    }
   private void checkbounds() { //MUST TEST
	   if(x_coord == Params.WORLD_WIDTH)
	   {x_coord =0;}
	   else if(x_coord == -1)
	   {x_coord = Params.WORLD_WIDTH-1;}
	  
	   if(y_coord == Params.WORLD_HEIGHT)
	   {y_coord =0;}
	   else if(y_coord == -1)
	   {y_coord =Params.WORLD_HEIGHT-1;}
	   
   }
    protected final void walk(int direction) { //MUST TEST
        // TODO: Complete this method
        	Params param = new Params();
    	if(direction == 0) {x_coord+=1;} //go right
    	else if(direction == 1) {x_coord+=1; y_coord-=1;} //diagonal up adn right
    	else if(direction == 2) {y_coord-=1;} //stragiht up
    	else if(direction == 3) {x_coord-=1; y_coord-=1;} //up and left;
    	else if(direction == 4) {x_coord-=1;} //left
    	else if(direction == 5) {x_coord-=1;y_coord+=1;} //down and left;
    	else if(direction == 6) {y_coord+=1;} //down
    	else if(direction == 7) {x_coord+=1;y_coord+=1;} //down and right
    	energy-= param.WALK_ENERGY_COST;
    	checkbounds();
    	
    }
    private static void Resolve(Critter A,Critter B)
    {
    	Method E;
    
		try {
			
			E = A.getClass().getSuperclass().getDeclaredMethod("setEnergy", int.class);
			E.setAccessible(true);
			E.invoke(A, A.getEnergy()+ B.getEnergy()/2);//reward half of the winners energy

		
			E = B.getClass().getSuperclass().getDeclaredMethod("setEnergy", int.class);
			E.setAccessible(true);
			E.invoke(B, 0); // B = dead
			
			String key = getCoords(A);
			WorldMap.put(key,A);//forDisplay
			
		
		} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
	
    }
    private static boolean GetHasMovedBeforeFinal(Critter crit)
    {
    	boolean output = false;
    	try {
			Method Move = crit.getClass().getSuperclass().getDeclaredMethod("GetHasMovedBefore");
			Move.setAccessible(true);
			output = (boolean) Move.invoke(crit);
		} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	return output;
    }
    private static void EvalMoveinFight(Critter A, Critter B,String key)
    {
    
    	boolean A_true = false; //if A ran from fight
    	if(!getCoords(A).equals(key) ) //if A walks/runs 
    	{
    		
    	if(WorldMap.get(getCoords(A)) == null && !GetHasMovedBeforeFinal(A)) //if empty space and not walked before
    	{A_true = true;}
    	else{setCoords(A,key);}//RESET
    	}
    	
    	/*EVALB*/
 
    	if(!getCoords(B).equals(key) && !GetHasMovedBeforeFinal(B)) //if B moved and/or didnt invoked walk/run before
    	{
    		if(WorldMap.get(getCoords(B)) != null ||  ( A_true && getCoords(B).equals(getCoords(A))) ) //if occupied  space OR  A ran and is in  same space
    		{setCoords(B,key);}
    	}
    	
    	
    }
    private static void doEncounters(ArrayList<Critter> fighters,String key) //WORKS O(N)
    {
    	if(fighters.size() <= 1) 
    	{return;}
    	
    	Critter A = fighters.get(0);
    	Critter B = fighters.get(1);
    
    	
    	boolean A_fight = A.fight(B.toString());
    	boolean B_fight = B.fight(A.toString());
    	//System.out.println("BEFORE" + getCoords(A));
    	//System.out.println("BEFORE" + getCoords(B));
    	EvalMoveinFight(A,B,key);
    	//System.out.println(getCoords(A));
    	//System.out.println(getCoords(B));
    	if(getCoords(A).equals(getCoords(B))) {
    	if(A.getEnergy() > 0 & B.getEnergy() > 0)
    	{
    		
    		int A_Dice;
    		int B_Dice;
    		if(A_fight)
    			{ A_Dice = getRandomInt(A.getEnergy());}
    		else {A_Dice = 0;}
    		
    		if(B_fight)
			{ B_Dice = getRandomInt(B.getEnergy());}
		else {B_Dice = 0;}
    	
	
    		if(A_Dice >= B_Dice)
    		{Resolve( A, B); //A=Winner; B =Loser;
    		}
    		
    		else
    		{Resolve( B, A); //A=Winner; B =Loser;
    	
    		}
    		
    	}
    	}
    	/* Gulag time*/
			
		
    	if(A.getEnergy() <= 0  || !getCoords(A).equals(key)) //or if A moved
    	{fighters.remove(0); 
    	if(B.getEnergy() <=0|| !getCoords(B).equals(key) ) {fighters.remove(0);}
    	}
    	else if(B.getEnergy() <= 0 || !getCoords(B).equals(key)) //or if B moved
    	{fighters.remove(1); }
    	
    	
    	doEncounters(fighters,key);  //recursive call; fights two at a time
    	
    }
  
    
    protected final void run(int direction) { //MUSTTEST
        // TODO: Complete this method
    	Params param = new Params();
    	int consto = direction;
    	walk(consto);
    	walk(consto);
    	energy +=(2*param.WALK_ENERGY_COST); //reset energy
    	energy-= param.RUN_ENERGY_COST; // subtract Run energy
    
    	
    }
  
    protected final void reproduce(Critter offspring, int direction) { //MUST TEST
        // TODO: Complete this method
    	
    	//Create new critter offspring class of class subty
    	
    	try {
    		if(energy < Params.MIN_REPRODUCE_ENERGY){return;}//Check energy_parent >= MIN_REPRODUCE_ENERGY 
			Method E;
			
			//Energy calc 
	    	int energy_child = (int) Math.floor(energy/2);
	    	energy= (int) Math.ceil(energy/2);//(round down child/2 round up parent/2
	    	
	    
	    	//set offspring to  current x and y cord; 
	    	E = offspring.getClass().getSuperclass().getDeclaredMethod("setX_coord",int.class);
	    	E.setAccessible(true);
	    	E.invoke(offspring, x_coord); 
	    	E = offspring.getClass().getSuperclass().getDeclaredMethod("setY_coord",int.class);
	    	E.setAccessible(true);
	    	E.invoke(offspring, y_coord); 
	    	
	    	
	    
	    	//invoke walk, reset energy
	    		offspring.walk(direction); 
	    		E = offspring.getClass().getSuperclass().getDeclaredMethod("setEnergy",int.class);
	    		E.setAccessible(true);E.invoke(offspring, energy_child);  //energy is what its sopposed to be
	    		babies.add(offspring);
	    	
	    	
		} catch (NoSuchMethodException|SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
    	
    	
    }
   

    /**
     * The TestCritter class allows some critters to "cheat". If you
     * want to create tests of your Critter model, you can create
     * subclasses of this class and then use the setter functions
     * contained here.
     * <p>
     * NOTE: you must make sure that the setter functions work with
     * your implementation of Critter. That means, if you're recording
     * the positions of your critters using some sort of external grid
     * or some other data structure in addition to the x_coord and
     * y_coord functions, then you MUST update these setter functions
     * so that they correctly update your grid/data structure.
     */
    static abstract class TestCritter extends Critter {

        protected void setEnergy(int new_energy_value) {
            super.energy = new_energy_value;
        }

        protected void setX_coord(int new_x_coord) {
            super.x_coord = new_x_coord;
        }

        protected void setY_coord(int new_y_coord) {
            super.y_coord = new_y_coord;
        }

        protected int getX_coord() {
            return super.x_coord;
        }

        protected int getY_coord() {
            return super.y_coord;
        }
        protected void EvalHasMovedBefore(boolean new_HasMoved)
        {
        	super.HasMoved = new_HasMoved;
        }
        protected boolean GetHasMovedBefore()
        {
        	return super.HasMoved;
        }
        /**
         * This method getPopulation has to be modified by you if you
         * are not using the population ArrayList that has been
         * provided in the starter code.  In any case, it has to be
         * implemented for grading tests to work.
         */
        protected static List<Critter> getPopulation() {
            return population;
        }

        /**
         * This method getBabies has to be modified by you if you are
         * not using the babies ArrayList that has been provided in
         * the starter code.  In any case, it has to be implemented
         * for grading tests to work.  Babies should be added to the
         * general population at either the beginning OR the end of
         * every timestep.
         */
        protected static List<Critter> getBabies() {
            return babies;
        }
    }
}
